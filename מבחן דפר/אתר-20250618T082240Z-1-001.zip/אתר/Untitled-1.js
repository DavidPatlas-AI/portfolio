import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DAPRTestUI {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DAPRTestUI::createGUI);
    }

    private static void createGUI() {
        JFrame frame = new JFrame("מבחן דפ\"ר - מצב אופליין");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);
        frame.setLayout(new GridLayout(3, 2, 10, 10));

        addButton(frame, "תרגול סדרות מספרים", e -> JOptionPane.showMessageDialog(null, "2, 4, 6, 8, ? — מהו המספר הבא?"));
        addButton(frame, "בדיקת קשרים מילוליים", e -> JOptionPane.showMessageDialog(null, "מה הקשר בין 'מים' ל'אש'? (הפכים או קשור)"));
        addButton(frame, "פתרון בעיות לוגיות", e -> JOptionPane.showMessageDialog(null, "אם כל הכלבים אוהבים לרוץ, ורקס הוא כלב, האם רקס אוהב לרוץ?"));
        addButton(frame, "חידת חשיבה מהירה", e -> JOptionPane.showMessageDialog(null, "מה תמיד עולה אך אף פעם לא יורד? (רמז: החיים)"));
        addButton(frame, "בדיקת מהירות תגובה", e -> JOptionPane.showMessageDialog(null, "לחץ על הכפתור כשאתה מוכן למבחן מהירות!"));
        addButton(frame, "סיום מבחן", e -> JOptionPane.showMessageDialog(null, "כל הכבוד! סיימת את מבחן דפ\"ר בהצלחה! 🎯"));

        frame.setVisible(true);
    }

    private static void addButton(JFrame frame, String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.addActionListener(listener);
        frame.add(button);
    }
}
