const CACHE_NAME = 'dafar-v1';
const ASSETS = [
    '/',
    '/index.html',
    '/offline.html',
    '/src/styles/main.css',
    '/src/styles/components.css',
    '/src/styles/animations.css',
    '/src/js/main.js',
    '/src/js/practice.js',
    '/src/js/tools.js',
    '/src/js/stats.js',
    '/src/js/ai-tools.js',
    '/manifest.json'
];

// התקנת Service Worker
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Opened cache');
                return cache.addAll(ASSETS);
            })
    );
});

// הפעלת Service Worker
self.addEventListener('activate', event => {
    const cacheWhitelist = [CACHE_NAME];

    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (!cacheWhitelist.includes(cacheName)) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

// טיפול בבקשות רשת
self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                // החזרה מהמטמון אם קיים
                if (response) {
                    return response;
                }

                // העתקת הבקשה כי אי אפשר להשתמש בה פעמיים
                const fetchRequest = event.request.clone();

                return fetch(fetchRequest)
                    .then(response => {
                        // בדיקה שהתגובה תקינה
                        if (!response || response.status !== 200 || response.type !== 'basic') {
                            return response;
                        }

                        // העתקת התגובה כי אי אפשר להשתמש בה פעמיים
                        const responseToCache = response.clone();

                        caches.open(CACHE_NAME)
                            .then(cache => {
                                cache.put(event.request, responseToCache);
                            });

                        return response;
                    })
                    .catch(() => {
                        // במקרה של שגיאת רשת, החזר דף שגיאה מהמטמון
                        if (event.request.mode === 'navigate') {
                            return caches.match('/offline.html');
                        }
                    });
            })
    );
});

// Background Sync
self.addEventListener('sync', (event) => {
    if (event.tag === 'sync-progress') {
        event.waitUntil(syncProgress());
    }
});

// Push Notifications
self.addEventListener('push', (event) => {
    const options = {
        body: event.data.text(),
        icon: '/icons/icon-192x192.png',
        badge: '/icons/badge.png',
        vibrate: [100, 50, 100],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        },
        actions: [
            {
                action: 'explore',
                title: 'פתח את האפליקציה',
                icon: '/icons/checkmark.png'
            },
            {
                action: 'close',
                title: 'סגור',
                icon: '/icons/close.png'
            }
        ]
    };
    
    event.waitUntil(
        self.registration.showNotification('דפ"ר - עדכון', options)
    );
});

// Notification Click
self.addEventListener('notificationclick', (event) => {
    event.notification.close();
    
    if (event.action === 'explore') {
        event.waitUntil(
            clients.openWindow('/')
        );
    }
});

// Handle offline functionality
self.addEventListener('message', event => {
    if (event.data === 'skipWaiting') {
        self.skipWaiting();
    }
}); 